# Neutral UI

参考 Neutral 固定提交 `e6f151507f3c70f483d4bd476fa69faef155fe8c` 制作的 React + TypeScript 组件库及交互展示页。

本次改动影响范围是 UI 组件库、动效目录和组件展示模块。

## 运行与构建

```sh
npm install
npm run dev
npm run build
```

开发服务地址以 Vite 输出为准。`site/` 为静态展示页，`dist/` 为 ESM 组件、类型定义和样式。`npm pack` 可生成本地安装包，当前包设为 private。

## 使用

```tsx
import { Theme, Button, Dialog, Input } from '@neutral-reference/ui';
import '@neutral-reference/ui/styles.css';

export function App() {
  return (
    <Theme theme="light">
      <Dialog trigger={<Button variant="primary">新建项目</Button>} title="新建项目">
        <Input aria-label="项目名称" placeholder="项目名称" />
      </Dialog>
    </Theme>
  );
}
```

`Theme` 支持 `light`、`dark`、`system`，可传 `reducedMotion`。弹层在主题容器中渲染，避免把容器放在带 transform 或 overflow 裁剪的祖先内。系统 `prefers-reduced-motion` 同样生效。

## 组件边界

- `controls` 负责基础控件、主题与输入，包含 Button、Badge、Input、Textarea、Field、Select、Checkbox、Switch、Slider、SegmentedControl、Tooltip、Spinner、Skeleton。
- `overlays` 负责弹层与反馈，包含 Dialog、Drawer、Popover、Menu、Accordion、ToastProvider、Toast、ToastDemo。焦点、方向键、Escape 与模态隔离复用 Radix UI。
- `data` 负责内容展示，包含 Card、EmptyState、Alert、Progress、QuotaRing、Stat、Sparkline、CodeBlock、AvatarStack、DataTable、SearchInput、AgentRow、ProviderCard、PluginCard、SessionItem、RoutingGraph、ContextGrid、Timeline、KeyValue、Breadcrumbs、RowActions。
- `patterns` 负责页面可组合单元，包含 SettingsRow、ProfilePicker、LibraryCard、MaskingText、GatewayCard、RoutingGroupCard、UsageBars、RequestLog、FileTree、ChatMessage、ModelPicker、FlowSteps。
- `motion` 负责原版关键帧和 FLIP 布局过渡，包含 Motion、Morph 和 motionPresets。

所有交互示例使用本地数据。业务组件通过属性及回调接入宿主。脱敏组件传入的原文本会存在于客户端，实际隐私处理应在数据进入 UI 前完成。

## 原版覆盖与追溯

`src/upstream/` 收录固定版本全部 290 个前端资源，保留目录，资源内的项目名称与标识已统一替换。`LICENSE` 和 `THIRD_PARTY_NOTICES` 保留上游许可。

```sh
npm run catalogue
```

生成 `src/catalogue.json`，记录所有资源的字节数和 SHA-256，以及 62 组 CSS 关键帧、434 处 CSS 动效声明、142 处 WAAPI/rAF 调用及其原文件行号。`src/tokens.css` 从上游提取主题变量。`src/motion/original.css` 保留全部关键帧并添加命名空间。

动效实验室可回放全部关键帧。OriginalMotion 使用对应的原版 DOM 和完整上游样式。上游的 JS 动效调用可在展示页逐项查看。Dialog 已提取原版的触发点形变几何与弹簧曲线，Morph 提供 FLIP 尺寸过渡。组件化后的归属、页面组合和宿主边界列在 [覆盖对照](docs/coverage.md)。OriginalMotion 为每条定义提供对应的原版 HTML/SVG 结构，支持原版曲线、播放方向、主题与回放控制。

原版 HTML 可以通过独立入口进行隔离样式预览。

```tsx
import { OriginalSurface } from '@neutral-reference/ui/original';

<OriginalSurface
  title="原版控件"
  html={'<button class="text">连接</button>'}
  height={120}
  theme="dark"
/>
```

`OriginalSurface` 的 iframe 沙箱禁止脚本执行，CSP 限制网络加载。该入口独立打包，按需引入。完整上游资源可通过 `@neutral-reference/ui/upstream/*` 访问。

## 当前交付

- React + TypeScript 组件库、ESM 产物、类型定义和独立样式入口。
- 78 个交互示例，支持组件搜索、代码复制、明暗主题与减少动态效果。
- 62 条原版关键帧定义，包含一个同名的减少动态效果变体。每条定义拥有独立 ID、源文件行号和播放参数。
- OriginalMotion 在对应的 HTML/SVG 结构上回放原版关键帧。
- 290 个上游资源、8 个样式文件、72 个脚本，保留许可、目录及逐文件 SHA-256。
- 434 处 CSS 动效声明与 142 处 WAAPI/rAF 调用的源码索引，记录所属函数和行号。

### 高级组件

| 能力 | API | 上游依据 |
| --- | --- | --- |
| 可中断导航弹簧 | SpringNavigation | app.js navTopStep，response 0.42，damping 0.84 |
| 列表与二维卡片排序 | SortableList，layout 为 list 或 grid | app.js dragRows、dragCards |
| 骨架喜鹊落下、跳跃、飞离 | LoadingBird、BirdLogo | app.js skelBird 与原版 SVG 分片 |
| 行内展开与反向中断 | ExpandableRow | app.js sheet |
| 安装进度、失败重试与容器形变 | InstallCard | plugins.js fill |
| 侧栏宽度调整 | ResizablePanel | app.js sideDrag |
| 时间线数据点检查 | ChartTimeline | context.js 时间线图表 |
| 候选与分配原因 | RoutingInspector | routing/client.js 路由可视化 |
| 数据驱动的路由节点、连线与飞行 | RoutingGraph | routing/client.js layout、fly，700ms 流线、1400ms 飞行 |
| 请求轨迹与重试回放 | TraceReplay | routing/client.js replay，空闲间隔上限 1800ms |
| 插件设置 schema | SchemaForm | kernel.js ui.form，布尔、枚举、数字与文本 |
| 指令与 JSON 文本编辑 | AutoTextarea | library/client.js autosize，保持父容器高度及保存快捷键 |
| 方向性内容切换 | ContentSwap | app.js switchPickerGroup，75/190ms |
| 缩略图展开 | ImagePreview | ctxtext.js picture，460ms |
| 摘要计数 | AnimatedNumber | redact/page.js maskCountUp，1100ms |
| 上下文矩形树图与细项聚合 | ContextMap | context.js squarify、tilesOf |
| 分批展开正文、图片、封存内容 | ContextDetails | ctxtext.js，正文每批 20,000 字符、项目每批 100 项 |
| 每日活动日历 | CalendarHeatmap | usage/page.js sessions 图表 |
| 页面侧栏、工具栏和窄屏导航 | PageShell | app.css sidebar 与 header |
| 紧凑托盘视图 | TrayPanel | app.css panel |
| 导航指针灯光与子列表编排 | SpringNavigation、NavigationGroup | navlamp.js、app.js navSubEnter/navSubLeave |
| 编辑器形变、滚动保持、保存描线 | InlineEditor、SaveFeedback | routing/client.js slotMorph/foldInSight/savedMark |
| 设置消耗调优曲线 | TuningChart | context.js chart |
| 索引扫描与进度点阵 | SessionIndex | usage/page.js sessIndexHero，14px 点距与 0.06 进度平滑 |
| 额度卡片紧凑排布 | Masonry | app.js packUsage，260px 列宽下限、7px 间隔 |
| 滚动端点胶囊 | ScrollEnds | scrollends.js |
| 按需设置说明与跟随提示 | SettingsRow、Tooltip | settingshints.js、context.js followTip |
| 路由条件按需增删与排序 | RoutingRuleEditor | routing/client.js，13 种条件 |
| MCP 表单与 JSON 同步 | MCPServerEditor | library/client.js editServer |
| Hook、子代理与多选绑定 | HookEditor、SubagentEditor、MultiSelect | library/client.js editHook/editSubagent/namesPick |
| 程序化外观效果 | ProgrammaticMotion、effectPresets | 原版标签、行、卡片、条形、路径与刷新 WAAPI |
| 高级编辑折叠 | ExpandableRow variant 为 editor | app.js，460ms 弹簧展开、280ms 关闭 |
| 原版脱敏视频与信件粒子 | MaskingDemo 独立入口 | redact/demo.js 原版控制器、视频与海报 |


SortableList 在放下时调用 onReorder，Escape 和 pointercancel 恢复原顺序。手柄支持鼠标、触控笔和触屏的指针捕获。键盘通过空格提起与放下、方向键移动。 指针由稳定的列表容器捕获，列表项换位时继续接收移动与放下事件。补充验收记录保存在 artifacts/followup-interaction-verification.json。

LoadingBird 只查询自身容器内的 Skeleton，450ms 后出现，使用原版的 300ms 落下、220ms 踩压、340ms 跳跃与 480ms 飞离。可见性、visibilitychange 与减少动态效果偏好控制启动和停止，卸载时取消计时器和动画。

ContextMap 支持 parts[].items、面积下限、最多 12 个独立细项、其余小项聚合和最小可读边长。onSelect 返回所属分组，onItemsSelect 返回该块包含的原始项目。ResizeObserver 根据实际容器尺寸更新布局。

ToastProvider 和受控 Toast 可以接入宿主操作反馈，ToastDemo 保留独立演示入口。

```tsx
import { motionPresets } from '@neutral-reference/ui';
import { OriginalMotion } from '@neutral-reference/ui/original';

<OriginalMotion preset={motionPresets[0].id} theme="dark" loop />
```

## 验证

```sh
npm run build
npm run verify
npm pack --pack-destination artifacts
```

已执行并通过以下检查。

- TypeScript 检查、展示页构建、组件库构建和声明文件生成。
- 全新安装包的 ESM 主入口、original、masking、样式与上游资源路径导入。严格 TypeScript 消费端在 skipLibCheck 为 false 时通过，包含显式 styles.css 导入。
- 290 个资源的 SHA-256 与清单一致，清单基于名称脱敏后的资源重新生成，不再与上游逐字节相同。
- 62 条定义拥有独立 ID，普通 led-req-in 保留位移，减少动态效果变体保留条件信息。
- 全部关键帧与 @property --shine-a 注册进入构建产物，全部原版预览包含匹配结构。
- 长文本在 20,000 字符处分批呈现，上下文小项聚合和微小分组保留通过回归检查。
- 逐条浏览 62 个原版预览，检查实际渲染目标、动画名称、尺寸与可见状态。ctx-grow 在 450ms 中间帧检查宽度。
- 首批 65 个示例挂载，列表/网格排序、安装重试、折叠、侧栏调整、图表、日历、图片展开、内容切换、树图和页面组合的交互路径检查。
- 减少动态效果开关、系统媒体偏好模拟、骨架喜鹊离屏停止和回到视区后恢复。
- 390 × 844 窄屏模拟中的导航、抽屉与 Escape。

证据保存在 artifacts/original-motion-verification.json、artifacts/advanced-verification.json、artifacts/composite-verification.json 及截图中。

自动化浏览器在切换 Agent 标签页时保持 document.hidden 为 false。visibilitychange 的暂停/恢复通过临时模拟该属性后触发事件验证，测试后恢复原生属性。真实触屏硬件和原生操作系统后台切换尚未验收。

源码浏览器按需保留完整上游文件，生产构建存在大文件块提示。当前目录没有 Git 元数据。

## 原版脱敏演示

```tsx
import { MaskingDemo } from '@neutral-reference/ui/masking';

<MaskingDemo theme="dark" reducedMotion={false} />
```

该入口按需加载原版视频、海报和控制器。演示在独立的不透明来源 iframe 中运行。CSP 将脚本限制在内置 nonce 脚本，图片与视频限制在打包资源来源和 data URL。尺寸消息校验 iframe 来源与数值，关闭演示时移除 iframe，释放文档、观察器和视频资源。

复用了原版 27.5 秒时间轴、8 个阶段、Bezier 信件轨迹、占位符替换、笔记本条目和回复恢复，保留播放、暂停、进度拖动及主题切换。示例账号与密码属于原版演示素材。

## 本轮新增验证

- 导航灯光的实际渐变样式，子导航展开与关闭。
- 行内编辑器的 570ms 展开、420ms 折叠和滚动恢复，取消时保留已保存值。
- 保存高亮、勾选描线和淡出。
- 上下文分组退出和重新进入，180ms 后移除失效条目。
- 调优图标记选择与当前设置更新。
- 原版视频解码并播放，跳转到 27.5 秒末尾、重播、切换暗色片源，减少动态效果时暂停到最终阶段，折叠后移除 iframe。
- 原版脱敏运行时的语法、隔离沙箱、初始偏好与打包媒体绑定回归检查。

相关浏览器证据保存在 artifacts/programmatic-verification.json 和 artifacts/masking-verification.json。

## 路由与编辑器验证

- 动态图测量节点位置并绘制 SVG 贝塞尔连线。
- 轨迹从 429 重试到第二个 Provider，4× 播放完成后保留全部尝试记录。
- 超过上限的数字字段标记无效并保留已提交值，修正后提交有效 patch。
- 多行文本增高到 342px，⌘ / Ctrl + S 保存，Escape 恢复已保存的 18 行正文。

证据保存在 artifacts/trace-editor-verification.json 和 artifacts/trace-replay.png。

## 页面组合与宿主边界

[覆盖对照](docs/coverage.md) 列出各源界面的组件组合，以及 142 处程序化调用的能力归属。基础组件、业务组合、原版关键帧、独立脱敏演示和完整源资源均可从包入口访问。原版的网络请求、账号操作、安装任务与平台桥接由宿主通过受控属性和回调接入。

新增的索引、脱敏流向、规则编辑和 MCP 编辑验证保存在 artifacts/effects-editor-verification.json。最终的全部示例挂载、包安装和新表单交互记录保存在 artifacts/final-verification.json。

## 名称脱敏

项目统一使用 Neutral UI，包名为 `@neutral-reference/ui`。参考资源中的名称、标识、存储键及文件名已同步替换，原项目外链改为不可解析的示例地址。版权及许可证条款保留。历史截图和旧安装包已移除，历史交互校验记录仅代表改名前的验收，不代表本次重新执行。
