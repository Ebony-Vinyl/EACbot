# 界面与动效覆盖

参考版本固定为 `e6f151507f3c70f483d4bd476fa69faef155fe8c`。库通过受控属性和回调承接宿主数据及操作。原版页面控制器、平台桥接、网络请求与轮询保留在 `src/upstream`，宿主负责业务处理。

## 前端能力

| 源界面 | 组件入口 | 主要来源 |
| --- | --- | --- |
| 应用框架、窗口与托盘 | PageShell、TrayPanel、ResizablePanel、SpringNavigation、NavigationGroup | app.js、layout.js、traywindows.js、panelarrange.js |
| Agents 与模型选择 | AgentRow、ModelPicker、MultiSelect、SegmentedControl、Dialog | app.js、agentsmanager.js、modelfind.js、agentsuffix.js |
| Providers 与额度 | ProviderCard、QuotaRing、Progress、Sparkline、ProfilePicker、Masonry | app.js、quotaall.js、keybalance.js、keyspend.js、ratewindows.js |
| 插件与安装 | PluginCard、InstallCard、SchemaForm、Alert | plugins.js、kernel.js、registry.js、setfeats.js |
| Library | LibraryCard、FileTree、AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect | plugins/library/client.js |
| Routing | RoutingGraph、RoutingInspector、RoutingGroupCard、RoutingRuleEditor、TraceReplay、InlineEditor、SaveFeedback | plugins/routing/client.js、ruleedit.js |
| Usage 与会话索引 | Stat、UsageBars、Masonry、DataTable、RequestLog、ChartTimeline、CalendarHeatmap、SessionIndex | plugins/usage/page.js |
| 会话与上下文 | SessionItem、ChatMessage、ContextMap、ContextDetails、TuningChart、ImagePreview | context.js、ctxtext.js、plugins/sessions/client.js |
| Privacy 与脱敏 | MaskingText、AnimatedNumber、MaskingFlow、MaskingDemo、ProgrammaticMotion | plugins/redact/page.js、plugins/redact/demo.js |
| Gateway、搜索与设置 | GatewayCard、SettingsRow、SchemaForm、Input、Select、Switch、Field、Tooltip | plugins/gateway/*、plugins/search/settings.js、settingshints.js |
| OTEL、通知、备份与确认 | DataTable、CodeBlock、Card、Alert、Toast、Dialog、Drawer | plugins/otel/page.js、notices.js、autobackup.js、quitask.js |
| 原版样式与媒体 | OriginalSurface、OriginalMotion、MaskingDemo、upstream 资源入口 | 8 个完整 CSS、290 个原始资源 |

## 提取方式

- 62 条关键帧按定义保留，包含同名的减少动态效果变体。OriginalMotion 使用原版 HTML/SVG 结构，浏览器逐条渲染证据保存在 `artifacts/original-motion-verification.json`。
- 程序化效果依其职责提取到组件。导航、排序、弹层、折叠、编辑、图表、路由、脱敏和索引具有各自的 React 状态与生命周期。路由节点和参数接口经过组件化整理，路由图中的每条活动连线使用独立飞行动画。
- 原版脱敏 27.5 秒演示保留原始控制器与视频，在隔离 iframe 内运行。
- rAF 调用也包含布局测量、焦点安排、业务轮询和渲染批处理。这些调用逐条列在下表。React 协调 DOM、Radix 管理弹层焦点、ResizeObserver 与 CSS 处理尺寸，宿主处理业务轮询。
- 434 处 CSS 动效声明可在源码索引按文件查看。完整 CSS 由原版预览加载，组件样式采用提取的主题变量和对应交互规则。

## 程序化调用对照

每行对应固定版本的一处 WAAPI 或 rAF 调用。表中的入口表示组件化后的能力归属，业务轮询和原版全局页面调度由宿主接入。

| 源位置 | 所属函数 | 调用 | 库内能力或宿主边界 |
| --- | --- | --- | --- |
| `app.js:839` | `more.onclick` | WAAPI | ProgrammaticMotion · label |
| `app.js:1509` | `sheet` | WAAPI | ExpandableRow · sheet |
| `app.js:1510` | `sheet` | WAAPI | ExpandableRow · sheet |
| `app.js:3102` | `paint` | requestAnimationFrame | SortableList |
| `app.js:3119` | `move` | requestAnimationFrame | SortableList |
| `app.js:3197` | `paint` | requestAnimationFrame | SortableList |
| `app.js:3214` | `move` | requestAnimationFrame | SortableList |
| `app.js:4843` | `followPick` | requestAnimationFrame | ModelPicker、MultiSelect 的选择定位 |
| `app.js:5123` | `switchPickerGroup` | WAAPI | ContentSwap |
| `app.js:5132` | `anonymous` | WAAPI | ContentSwap |
| `app.js:7639` | `anonymous` | requestAnimationFrame | Dialog 的焦点管理 |
| `app.js:7900` | `anonymous` | WAAPI | ExpandableRow · editor、Morph 容器组合 |
| `app.js:7905` | `anonymous` | WAAPI | ExpandableRow · editor、Morph 容器组合 |
| `app.js:7906` | `anonymous` | WAAPI | ExpandableRow · editor、Morph 容器组合 |
| `app.js:7908` | `anonymous` | WAAPI | ExpandableRow · editor、Morph 容器组合 |
| `app.js:7914` | `anonymous` | WAAPI | ExpandableRow · editor、Morph 容器组合 |
| `app.js:8580` | `step` | requestAnimationFrame | LoadingBird |
| `app.js:8581` | `anonymous` | requestAnimationFrame | LoadingBird |
| `app.js:8598` | `skelBird` | WAAPI | LoadingBird |
| `app.js:8604` | `skelBird` | WAAPI | LoadingBird |
| `app.js:8628` | `skelBird` | WAAPI | LoadingBird |
| `app.js:8881` | `holdModal` | requestAnimationFrame | Dialog |
| `app.js:8978` | `openModal` | WAAPI | Dialog |
| `app.js:8979` | `openModal` | WAAPI | Dialog |
| `app.js:8981` | `openModal` | WAAPI | Dialog |
| `app.js:8982` | `openModal` | WAAPI | Dialog |
| `app.js:9011` | `anonymous` | requestAnimationFrame | Dialog |
| `app.js:9040` | `closeModal` | WAAPI | Dialog |
| `app.js:9041` | `closeModal` | WAAPI | Dialog |
| `app.js:9042` | `closeModal` | WAAPI | Dialog |
| `app.js:9045` | `closeModal` | WAAPI | Dialog |
| `app.js:9174` | `slides` | WAAPI | SegmentedControl 的 280ms 滑块 |
| `app.js:11373` | `anonymous` | requestAnimationFrame | MultiSelect、ModelPicker 的自适应列表 |
| `app.js:15671` | `step` | requestAnimationFrame | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15673` | `$("#addProvider").onclick` | requestAnimationFrame | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15717` | `unrollSheet` | WAAPI | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15722` | `unrollSheet` | WAAPI | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15733` | `follow` | requestAnimationFrame | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15737` | `unrollSheet` | requestAnimationFrame | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15764` | `frame` | requestAnimationFrame | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15767` | `unrollInView` | requestAnimationFrame | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:15776` | `rollUpSheet` | WAAPI | InlineEditor、ExpandableRow 的展开与滚动 |
| `app.js:16125` | `renderQuotas` | requestAnimationFrame | ProviderCard、QuotaRing、TrayPanel 的布局和焦点 |
| `app.js:16384` | `anonymous` | requestAnimationFrame | Masonry |
| `app.js:17209` | `panelQuotaFocus` | requestAnimationFrame | ProviderCard、QuotaRing、TrayPanel 的布局和焦点 |
| `app.js:17565` | `renderPanelQuota` | requestAnimationFrame | ProviderCard、QuotaRing、TrayPanel 的布局和焦点 |
| `app.js:18304` | `anonymous` | requestAnimationFrame | ProviderCard、QuotaRing、TrayPanel 的布局和焦点 |
| `app.js:18428` | `anonymous` | requestAnimationFrame | ProviderCard、QuotaRing、TrayPanel 的布局和焦点 |
| `app.js:18455` | `b.onclick` | WAAPI | ProgrammaticMotion · refresh |
| `app.js:19814` | `anonymous` | requestAnimationFrame | SearchInput 的受控检索 |
| `app.js:22764` | `anonymous` | requestAnimationFrame | Radix 弹层焦点、原生滚动 |
| `app.js:22764` | `keyboardFocus` | requestAnimationFrame | Radix 弹层焦点、原生滚动 |
| `app.js:23096` | `keepHeld` | requestAnimationFrame | PageShell 的宿主滚动位置、InlineEditor 滚动保持 |
| `app.js:23118` | `anonymous` | requestAnimationFrame | PageShell 的宿主滚动位置、InlineEditor 滚动保持 |
| `app.js:23196` | `show` | requestAnimationFrame | PageShell 的宿主滚动位置、InlineEditor 滚动保持 |
| `app.js:23901` | `navSubMark` | requestAnimationFrame | SpringNavigation |
| `app.js:23948` | `anonymous` | requestAnimationFrame | SpringNavigation |
| `app.js:23948` | `navTopGo` | requestAnimationFrame | SpringNavigation |
| `app.js:23954` | `navTopGo` | WAAPI | SpringNavigation |
| `app.js:23957` | `navTopGo` | requestAnimationFrame | SpringNavigation |
| `app.js:23991` | `navTopStep` | requestAnimationFrame | SpringNavigation |
| `app.js:23998` | `navSubEnter` | WAAPI | NavigationGroup |
| `app.js:24004` | `anonymous` | WAAPI | NavigationGroup |
| `app.js:24007` | `navSubEnter` | WAAPI | NavigationGroup |
| `app.js:24018` | `navSubLeave` | WAAPI | NavigationGroup |
| `app.js:24090` | `again` | requestAnimationFrame | PageShell、响应式 CSS 与 ResizeObserver |
| `app.js:24101` | `tools` | requestAnimationFrame | PageShell、响应式 CSS 与 ResizeObserver |
| `app.js:24213` | `later` | requestAnimationFrame | PageShell、响应式 CSS 与 ResizeObserver |
| `autobackup.js:120` | `autoBackupRows` | requestAnimationFrame | Radix 弹层焦点与宿主更新后的焦点恢复 |
| `context.js:212` | `anonymous` | requestAnimationFrame | ContextMap、AnimatedNumber · context、Tooltip · follow、Morph |
| `context.js:250` | `step` | requestAnimationFrame | ContextMap、AnimatedNumber · context、Tooltip · follow、Morph |
| `context.js:533` | `go` | requestAnimationFrame | ContextMap、AnimatedNumber · context、Tooltip · follow、Morph |
| `context.js:535` | `followTip` | requestAnimationFrame | ContextMap、AnimatedNumber · context、Tooltip · follow、Morph |
| `context.js:613` | `anonymous` | WAAPI | ContextMap、AnimatedNumber · context、Tooltip · follow、Morph |
| `context.js:621` | `drawMap` | WAAPI | ContextMap、AnimatedNumber · context、Tooltip · follow、Morph |
| `context.js:654` | `setLook` | WAAPI | ContextMap、AnimatedNumber · context、Tooltip · follow、Morph |
| `ctxtext.js:66` | `fig.onclick` | WAAPI | ImagePreview |
| `navlamp.js:35` | `frame` | requestAnimationFrame | SpringNavigation / useNavigationLamp |
| `navlamp.js:37` | `go` | requestAnimationFrame | SpringNavigation / useNavigationLamp |
| `plugins.js:958` | `drawBody` | requestAnimationFrame | InstallCard、Morph、宿主安装进度回调 |
| `plugins.js:1619` | `step` | requestAnimationFrame | InstallCard、Morph、宿主安装进度回调 |
| `plugins.js:1621` | `anonymous` | requestAnimationFrame | InstallCard、Morph、宿主安装进度回调 |
| `plugins.js:1797` | `fill` | WAAPI | InstallCard、Morph、宿主安装进度回调 |
| `plugins.js:1798` | `fill` | WAAPI | InstallCard、Morph、宿主安装进度回调 |
| `plugins/library/client.js:1139` | `anonymous` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:2061` | `autosize` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:2955` | `browserAsk` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:3875` | `editServer` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:4166` | `editHook` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:4374` | `editSubagent` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:5316` | `nameBar` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:5406` | `queueLists` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:7439` | `serverSheet` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/library/client.js:7540` | `browserSetup` | requestAnimationFrame | AutoTextarea、MCPServerEditor、HookEditor、SubagentEditor、MultiSelect；宿主浏览器连接与轮询 |
| `plugins/redact/demo.js:430` | `frame` | requestAnimationFrame | MaskingDemo 原版控制器 |
| `plugins/redact/demo.js:439` | `wake` | requestAnimationFrame | MaskingDemo 原版控制器 |
| `plugins/redact/page.js:176` | `drawMaskCard` | WAAPI | AnimatedNumber、MaskingFlow、ProgrammaticMotion · maskingCard/maskingBar/maskingWire |
| `plugins/redact/page.js:262` | `step` | requestAnimationFrame | AnimatedNumber、MaskingFlow、ProgrammaticMotion · maskingCard/maskingBar/maskingWire |
| `plugins/redact/page.js:264` | `maskCountUp` | requestAnimationFrame | AnimatedNumber、MaskingFlow、ProgrammaticMotion · maskingCard/maskingBar/maskingWire |
| `plugins/redact/page.js:291` | `anonymous` | WAAPI | AnimatedNumber、MaskingFlow、ProgrammaticMotion · maskingCard/maskingBar/maskingWire |
| `plugins/redact/page.js:379` | `anonymous` | WAAPI | AnimatedNumber、MaskingFlow、ProgrammaticMotion · maskingCard/maskingBar/maskingWire |
| `plugins/routing/client.js:327` | `anonymous` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:344` | `metaFit` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:1727` | `kick` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:2026` | `flowSoon` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:2145` | `placeSoon` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:2230` | `layout` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:3288` | `anonymous` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:4205` | `renderHist` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:4399` | `anonymous` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:4545` | `redrawList` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:5107` | `renderAll` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:5345` | `replay` | requestAnimationFrame | TraceReplay |
| `plugins/routing/client.js:5390` | `step` | requestAnimationFrame | TraceReplay |
| `plugins/routing/client.js:5537` | `frame` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:6469` | `slotMorph` | WAAPI | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6477` | `slotMorph` | WAAPI | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6481` | `slotMorph` | WAAPI | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6501` | `step` | requestAnimationFrame | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6503` | `foldInSight` | requestAnimationFrame | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6509` | `savedMark` | WAAPI | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6517` | `savedMark` | WAAPI | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6520` | `savedMark` | WAAPI | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:6521` | `savedMark` | WAAPI | InlineEditor、SaveFeedback |
| `plugins/routing/client.js:7979` | `fitBox` | requestAnimationFrame | RoutingRuleEditor、CSS 自适应条件行 |
| `plugins/routing/client.js:8028` | `fitCondsSoon` | requestAnimationFrame | RoutingRuleEditor、CSS 自适应条件行 |
| `plugins/routing/client.js:9015` | `anonymous` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:9034` | `pTick` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:9271` | `anonymous` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/routing/client.js:9288` | `fitSoon` | requestAnimationFrame | RoutingGraph、RoutingInspector、TraceReplay、ResizeObserver 与宿主轨迹数据 |
| `plugins/search/settings.js:237` | `anonymous` | requestAnimationFrame | Radix 弹层焦点与宿主更新后的焦点恢复 |
| `plugins/usage/page.js:1452` | `look` | requestAnimationFrame | SessionIndex、CalendarHeatmap、DataTable、SpringNavigation；宿主请求加载 |
| `plugins/usage/page.js:2394` | `anonymous` | requestAnimationFrame | SessionIndex、CalendarHeatmap、DataTable、SpringNavigation；宿主请求加载 |
| `plugins/usage/page.js:2413` | `anonymous` | requestAnimationFrame | SessionIndex、CalendarHeatmap、DataTable、SpringNavigation；宿主请求加载 |
| `plugins/usage/page.js:3558` | `loop` | requestAnimationFrame | SessionIndex、CalendarHeatmap、DataTable、SpringNavigation；宿主请求加载 |
| `plugins/usage/page.js:3560` | `sessIndexHero` | requestAnimationFrame | SessionIndex、CalendarHeatmap、DataTable、SpringNavigation；宿主请求加载 |
| `plugins/usage/page.js:3561` | `sessIndexHero` | requestAnimationFrame | SessionIndex、CalendarHeatmap、DataTable、SpringNavigation；宿主请求加载 |
| `plugins/usage/page.js:4006` | `anonymous` | requestAnimationFrame | SessionIndex、CalendarHeatmap、DataTable、SpringNavigation；宿主请求加载 |
| `scrollends.js:52` | `later` | requestAnimationFrame | ScrollEnds |
| `scrollends.js:82` | `settle` | requestAnimationFrame | ScrollEnds |
| `scrollends.js:86` | `go` | requestAnimationFrame | ScrollEnds |
| `settingshints.js:53` | `show` | requestAnimationFrame | SettingsRow · hintOnDemand、Tooltip · 450ms |

## 验证证据

构建和声明文件通过 `npm run build` 生成，固定源资源、关键帧结构、长文本分批及隔离演示通过 `npm run verify` 检查。浏览器证据保存在 `artifacts` 内，包含原版关键帧、基础和高级交互、编辑器与原版视频。最后交付记录以 `artifacts/final-verification.json` 为准。

自动化浏览器的 PageDown 与滚轮在新增滚动示例中没有改变 scrollTop，初始滚动通过 DOM scrollTo 设置，随后以真实按钮验证平滑到顶、到底和禁用状态。真实触屏硬件与原生操作系统后台切换仍未验收。
